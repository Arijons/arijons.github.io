# VEF-2-Lokaverkefni-Vor-2018
# Þetta er lokaverkefni vorið 2018 og er í fullri vinnslu
