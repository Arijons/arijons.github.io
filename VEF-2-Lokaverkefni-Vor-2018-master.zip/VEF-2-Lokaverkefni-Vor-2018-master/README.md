# VEF-2-Lokaverkefni-Vor-2018
# 			Cash Money
			
Útgáfufyrirtækið Cash Money sem er nýstofnað ætlar að hasla sér völl í tónlistabransanum og stefnir á að halda tónleika í Laugardalshöll. Fyrirtækið er búið að gera samninga við efnilega tónlistarmenn og stefnir á að koma þeim á vinsældalista heimsins og síðar að halda út í djúpu laugina og sigra heiminn.

Eigendurnir heita Ari Jónsson og Vladislav Krasovsky.

Fyrirtækið er statt í Reykjavík
